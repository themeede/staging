#!/usr/bin/env python3
"""UFC sportsbook probability sharpness, 2024-2026 YTD.

Official results: UFCStats completed-event pages.
Bookmaker closing-line proxies: BestFightOdds completed-event pages.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import time
import unicodedata
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import numpy as np
import pandas as pd
import requests
from bs4 import BeautifulSoup

START_DATE = date(2024, 1, 1)
END_DATE = date(2026, 8, 30)
BFO_ROOT = "https://www.bestfightodds.com"
BFO_SITEMAP = f"{BFO_ROOT}/sitemap-events.xml"
UFCSTATS_EVENTS = "http://ufcstats.com/statistics/events/completed?page=all"
USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "Chrome/126.0 Safari/537.36 UFC-market-research/1.0"
)

BOOK_ALIASES = {
    "Pinnacle Sports": "Pinnacle", "Pinnacle": "Pinnacle",
    "BookMaker": "Bookmaker", "Bookmaker": "Bookmaker",
    "Bet Online": "BetOnline", "BetOnline": "BetOnline",
    "Draft Kings": "DraftKings", "DraftKings": "DraftKings",
    "Fan Duel": "FanDuel", "FanDuel": "FanDuel",
    "Bet MGM": "BetMGM", "BetMGM": "BetMGM",
    "Caesars Sportsbook": "Caesars", "Caesars": "Caesars",
    "Bet Rivers": "BetRivers", "BetRivers": "BetRivers",
}

NAME_ALIASES = {
    "raul rosas": "raul rosas jr", "raul rosas jr": "raul rosas jr",
    "ovince saint preux": "ovince st preux", "ovince st preux": "ovince st preux",
    "junyong park": "jun yong park", "da woon jung": "da un jung",
    "matthew semelsberger": "matt semelsberger",
    "montserrat conejo ruiz": "montserrat ruiz",
    "mizuki inoue": "mizuki", "danaa batgerel": "batgerel danaa",
    "asu almabaev": "asu almabayev", "su mudaerji": "sumudaerji",
    "park hyun sung": "hyunsung park", "lee jeong yeong": "jeongyeong lee",
    "doo ho choi": "dooho choi", "carlos diego ferreira": "diego ferreira",
    "elizeu zaleski dos santos": "elizeu zaleski",
    "sergey pavlovich": "sergei pavlovich",
    "alexander romanov": "alexandr romanov", "ronaldo souza": "jacare souza",
}


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\xa0", " ").split())


def strip_accents(value: str) -> str:
    return "".join(
        c for c in unicodedata.normalize("NFKD", value)
        if not unicodedata.combining(c)
    )


def norm_name(value: Any) -> str:
    text = strip_accents(clean_text(value)).casefold()
    text = re.sub(r"[‘’'`´]", "", text)
    text = re.sub(r"\b(junior|jr\.?|senior|sr\.?)\b", " jr ", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = " ".join(text.split())
    return NAME_ALIASES.get(text, text)


def pair_key(left: Any, right: Any) -> tuple[str, str]:
    return tuple(sorted((norm_name(left), norm_name(right))))


def extract_id(url: Any) -> str:
    path = urlparse(str(url or "")).path.rstrip("/")
    return path.split("/")[-1]


def parse_date_iso(value: Any) -> str:
    text = clean_text(value)
    for fmt in ("%B %d, %Y", "%b %d, %Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    return ""


def request_text(session: requests.Session, url: str, attempts: int = 5) -> str:
    last: Exception | None = None
    for attempt in range(attempts):
        try:
            response = session.get(url, timeout=50, allow_redirects=True)
            response.raise_for_status()
            return response.text
        except requests.RequestException as exc:
            last = exc
            time.sleep(1.25 * (attempt + 1))
    raise RuntimeError(f"GET failed: {url}: {last}")


@dataclass(frozen=True)
class EventSummary:
    event_id: str
    event_url: str
    event_name: str
    event_date: str
    event_location: str


def parse_completed_events_html(html: str) -> list[EventSummary]:
    soup = BeautifulSoup(html, "html.parser")
    rows: list[EventSummary] = []
    for row in soup.select("tr.b-statistics__table-row"):
        link = row.select_one("a[href*='event-details']")
        cells = row.find_all("td", recursive=False)
        if link is None or len(cells) < 2:
            continue
        lines = [clean_text(x) for x in cells[0].stripped_strings if clean_text(x)]
        if len(lines) < 2:
            continue
        event_name, event_date = lines[0], lines[1]
        iso = parse_date_iso(event_date)
        if not iso:
            continue
        dt = date.fromisoformat(iso)
        if not (START_DATE <= dt <= END_DATE):
            continue
        # UFCStats also lists DWCS; retain UFC-branded and TUF finales only.
        if not (event_name.casefold().startswith("ufc") or "ultimate fighter" in event_name.casefold()):
            continue
        event_url = str(link.get("href", ""))
        rows.append(EventSummary(
            extract_id(event_url), event_url, event_name, event_date,
            clean_text(cells[1].get_text(" ", strip=True)),
        ))
    return rows


def table_texts(cell: Any) -> list[str]:
    texts = [clean_text(p.get_text(" ", strip=True)) for p in cell.select("p")]
    texts = [t for t in texts if t]
    if texts:
        return texts
    raw = clean_text(cell.get_text(" ", strip=True))
    return [raw] if raw else []


def parse_ufc_event_page(summary: EventSummary, html: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    soup = BeautifulSoup(html, "html.parser")
    title = soup.find("h2", class_="b-content__title")
    event_name = clean_text(title.get_text(" ", strip=True)) if title else summary.event_name
    event_date, event_location = summary.event_date, summary.event_location
    for item in [clean_text(li.get_text(" ", strip=True)) for li in soup.select("li.b-list__box-list-item")]:
        if item.startswith("Date:"):
            event_date = clean_text(item.split(":", 1)[1])
        elif item.startswith("Location:"):
            event_location = clean_text(item.split(":", 1)[1])
    event = {
        "event_id": summary.event_id, "event_url": summary.event_url,
        "event_name": event_name, "event_date": event_date,
        "event_date_iso": parse_date_iso(event_date), "event_location": event_location,
    }
    fights: list[dict[str, Any]] = []
    rows = soup.select("tr.b-fight-details__table-row")
    for order, row in enumerate(rows[1:], start=1):
        cells = row.find_all("td", recursive=False)
        links = cells[1].select("a[href*='fighter-details']") if len(cells) >= 2 else []
        if len(cells) < 10 or len(links) != 2:
            continue
        result_code = clean_text(" ".join(table_texts(cells[0]))).lower()
        f1, f2 = clean_text(links[0].get_text(" ", strip=True)), clean_text(links[1].get_text(" ", strip=True))
        fight_url = str(row.get("data-link", ""))
        fights.append({
            **event, "fight_id": extract_id(fight_url), "fight_url": fight_url,
            "fight_order": order, "fighter_1_name": f1, "fighter_2_name": f2,
            "winner_name": f1 if result_code == "win" else "",
            "result_code": result_code,
            "weight_class": clean_text(cells[6].get_text(" ", strip=True)),
        })
    return event, fights


def parse_bfo_sitemap(html: str) -> list[tuple[str, date]]:
    root = ET.fromstring(html)
    rows: list[tuple[str, date]] = []
    for node in root.findall(".//{*}url"):
        loc = clean_text(node.findtext("{*}loc"))
        modified = clean_text(node.findtext("{*}lastmod"))[:10]
        if not loc or "/events/" not in loc:
            continue
        slug = urlparse(loc).path.rstrip("/").split("/")[-1].casefold()
        if "ufc" not in slug:
            continue
        try:
            dt = date.fromisoformat(modified)
        except ValueError:
            m = re.search(r"(20(?:24|25|26))-([01]\d)-([0-3]\d)", slug)
            if not m:
                continue
            dt = date.fromisoformat("-".join(m.groups()))
        if START_DATE <= dt <= END_DATE:
            rows.append((loc, dt))
    return sorted(set(rows), key=lambda x: (x[1], x[0]))


def parse_bfo_event_name(html: str, fallback: str) -> str:
    match = re.search(
        r'content="Compare betting odds for ([^"]+?) on [A-Za-z]+ \d{1,2}, \d{4}',
        html, flags=re.I,
    )
    if match:
        return clean_text(match.group(1))
    if " Odds:" in fallback:
        return fallback.split(" Odds:", 1)[-1].split(" for ", 1)[0].strip()
    return fallback


def parse_bfo_event_date(html: str) -> str:
    match = re.search(r"on ([A-Za-z]+ \d{1,2}, \d{4})", html, flags=re.I)
    return parse_date_iso(match.group(1)) if match else ""


def book_name_from_header(th: Any, book_id: str) -> str:
    name = clean_text(th.get_text(" ", strip=True))
    if not name:
        image = th.find("img")
        if image is not None:
            name = clean_text(image.get("alt") or image.get("title"))
    if not name:
        link = th.find("a")
        if link is not None:
            name = clean_text(link.get("title") or link.get("data-original-title"))
    return BOOK_ALIASES.get(name, name or f"Book_{book_id}")


def parse_bfo_event_page(url: str, html: str, fallback_date: date) -> dict[str, Any]:
    soup = BeautifulSoup(html, "html.parser")
    fallback_title = clean_text(soup.title.get_text(" ", strip=True)) if soup.title else ""
    event_name = parse_bfo_event_name(html, fallback_title)
    event_date_iso = parse_bfo_event_date(html) or fallback_date.isoformat()
    source_event_id = extract_id(url)
    event = {
        "source_event_id": source_event_id, "event_name": event_name,
        "event_date_iso": event_date_iso, "event_url": url,
    }
    tables = soup.find_all("table")
    if len(tables) < 2:
        if soup.select_one("div.no-odds") is not None:
            return {"event": event, "matchups": [], "quotes": []}
        raise ValueError("missing odds table")
    odds_table = tables[1]
    header = odds_table.find("tr")
    if header is None:
        raise ValueError("missing odds header")
    books: list[dict[str, str]] = []
    for th in header.find_all("th")[1:]:
        book_id = clean_text(th.get("data-b"))
        if book_id:
            books.append({"bookmaker_id": book_id, "bookmaker_name": book_name_from_header(th, book_id)})
    matchups: list[dict[str, Any]] = []
    quotes: list[dict[str, Any]] = []
    buffer: list[dict[str, Any]] = []
    for row in odds_table.find_all("tr")[1:]:
        th = row.find("th")
        link = th.find("a", href=re.compile(r"/fighters/")) if th else None
        if link is None:
            continue
        fighter = clean_text(link.get_text(" ", strip=True))
        fighter_url = str(link.get("href", ""))
        cells = row.find_all("td", recursive=False)
        prop = row.select_one("td.prop-cell-exp")
        matchup_id = clean_text(prop.get("data-mu")) if prop else ""
        for index, book in enumerate(books):
            if index >= len(cells):
                break
            span = cells[index].find("span")
            display = clean_text(span.get_text(" ", strip=True)) if span else ""
            display = display.rstrip("▲▼").strip()
            if display:
                quotes.append({
                    "source_event_id": source_event_id, "source_matchup_id": matchup_id,
                    "bookmaker_id": book["bookmaker_id"], "bookmaker_name": book["bookmaker_name"],
                    "fighter_name": fighter, "fighter_url": fighter_url,
                    "american_odds": display,
                })
        buffer.append({"fighter_name": fighter, "fighter_url": fighter_url, "matchup_id": matchup_id})
        if len(buffer) == 2:
            left, right = buffer
            matchups.append({
                **event,
                "source_matchup_id": left["matchup_id"] or right["matchup_id"],
                "fighter_1_name": left["fighter_name"], "fighter_2_name": right["fighter_name"],
                "fighter_1_url": left["fighter_url"], "fighter_2_url": right["fighter_url"],
                "pair_key": pair_key(left["fighter_name"], right["fighter_name"]),
            })
            buffer = []
    return {"event": event, "matchups": matchups, "quotes": quotes}


def american_number(value: Any) -> float | None:
    text = clean_text(value).replace("−", "-").replace("–", "-").replace(",", "")
    match = re.search(r"[+-]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        number = float(match.group())
    except ValueError:
        return None
    return number if number and math.isfinite(number) else None


def implied_probability(value: Any) -> float | None:
    odds = american_number(value)
    if odds is None:
        return None
    return 100.0 / (odds + 100.0) if odds > 0 else (-odds) / ((-odds) + 100.0)


def scrape_ufcstats(session: requests.Session) -> tuple[pd.DataFrame, pd.DataFrame]:
    summaries = parse_completed_events_html(request_text(session, UFCSTATS_EVENTS))
    events: list[dict[str, Any]] = []
    fights: list[dict[str, Any]] = []
    for i, summary in enumerate(summaries, 1):
        event, event_fights = parse_ufc_event_page(summary, request_text(session, summary.event_url))
        events.append(event)
        fights.extend(f for f in event_fights if f["winner_name"])
        if i % 20 == 0:
            print(f"UFCStats {i}/{len(summaries)}", flush=True)
        time.sleep(0.04)
    df = pd.DataFrame(fights)
    if df.empty:
        raise RuntimeError("No decisive UFCStats fights parsed")
    df["pair_key"] = [pair_key(a, b) for a, b in zip(df.fighter_1_name, df.fighter_2_name)]
    return pd.DataFrame(events), df


def scrape_bfo(session: requests.Session) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    candidates = parse_bfo_sitemap(request_text(session, BFO_SITEMAP))
    events, matchups, quotes, failures = [], [], [], []
    for i, (url, sitemap_date) in enumerate(candidates, 1):
        try:
            parsed = parse_bfo_event_page(url, request_text(session, url), sitemap_date)
            event = parsed["event"]
            dt = date.fromisoformat(event["event_date_iso"][:10])
            if START_DATE <= dt <= END_DATE and "ufc" in event["event_name"].casefold():
                events.append(event)
                matchups.extend(parsed["matchups"])
                for q in parsed["quotes"]:
                    q.update({"event_name": event["event_name"], "event_date_iso": event["event_date_iso"], "event_url": url})
                    quotes.append(q)
        except Exception as exc:
            failures.append({"event_url": url, "sitemap_date": sitemap_date.isoformat(), "error_type": type(exc).__name__, "error": str(exc)[:500]})
        if i % 20 == 0:
            print(f"BFO {i}/{len(candidates)}", flush=True)
        time.sleep(0.09)
    if not matchups or not quotes:
        raise RuntimeError(f"No BFO quotes parsed; candidates={len(candidates)}, failures={len(failures)}")
    return pd.DataFrame(events), pd.DataFrame(matchups), pd.DataFrame(quotes), pd.DataFrame(failures)


def name_similarity(a: Any, b: Any) -> float:
    return SequenceMatcher(None, norm_name(a), norm_name(b)).ratio()


def pair_similarity(a1: Any, a2: Any, b1: Any, b2: Any) -> float:
    return max(
        (name_similarity(a1, b1) + name_similarity(a2, b2)) / 2,
        (name_similarity(a1, b2) + name_similarity(a2, b1)) / 2,
    )


def match_fights(bfo: pd.DataFrame, ufc: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    by_date_pair: dict[tuple[str, tuple[str, str]], list[int]] = defaultdict(list)
    by_date: dict[str, list[int]] = defaultdict(list)
    for idx, row in ufc.iterrows():
        by_date_pair[(row.event_date_iso, row.pair_key)].append(idx)
        by_date[row.event_date_iso].append(idx)
    matched, unmatched = [], []
    for _, row in bfo.iterrows():
        source_date = str(row.event_date_iso)[:10]
        dt = date.fromisoformat(source_date)
        dates = [(dt + timedelta(days=off)).isoformat() for off in (0, -1, 1)]
        exact = []
        for d in dates:
            exact.extend(by_date_pair.get((d, row.pair_key), []))
        candidates: list[tuple[int, str, float]] = [(idx, "exact_pair", 1.0) for idx in sorted(set(exact))]
        if not candidates:
            fuzzy: list[tuple[int, str, float]] = []
            for d in dates:
                for idx in by_date.get(d, []):
                    target = ufc.loc[idx]
                    score = pair_similarity(row.fighter_1_name, row.fighter_2_name, target.fighter_1_name, target.fighter_2_name)
                    if score >= 0.88:
                        fuzzy.append((idx, "fuzzy_pair", score))
            fuzzy.sort(key=lambda x: x[2], reverse=True)
            if fuzzy and (len(fuzzy) == 1 or fuzzy[0][2] - fuzzy[1][2] >= 0.03):
                candidates = [fuzzy[0]]
        if len(candidates) != 1:
            unmatched.append({**row.to_dict(), "reason": "ambiguous" if candidates else "unmatched", "candidate_count": len(candidates)})
            continue
        idx, method, similarity = candidates[0]
        target = ufc.loc[idx]
        matched.append({
            **row.to_dict(), "ufc_fight_id": target.fight_id,
            "ufc_event_id": target.event_id, "ufc_event_name": target.event_name,
            "ufc_event_date_iso": target.event_date_iso,
            "winner_name": target.winner_name, "fight_order": int(target.fight_order),
            "weight_class": target.weight_class, "match_method": method,
            "match_similarity": similarity,
        })
    result = pd.DataFrame(matched)
    if not result.empty:
        result = result.sort_values(["ufc_event_date_iso", "ufc_fight_id", "source_matchup_id"]).drop_duplicates("ufc_fight_id", keep="first")
    return result, pd.DataFrame(unmatched)


def build_forecasts(matched: pd.DataFrame, quotes: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    quotes = quotes.copy()
    quotes["Book"] = quotes.bookmaker_name.map(lambda x: BOOK_ALIASES.get(clean_text(x), clean_text(x)))
    records, rejected = [], []
    for _, fight in matched.iterrows():
        group = quotes[
            (quotes.source_event_id.astype(str) == str(fight.source_event_id)) &
            (quotes.source_matchup_id.astype(str) == str(fight.source_matchup_id))
        ]
        side1, side2 = norm_name(fight.fighter_1_name), norm_name(fight.fighter_2_name)
        for book, rows in group.groupby("Book"):
            if not book:
                continue
            lookup = {norm_name(r.fighter_name): r for _, r in rows.iterrows()}
            r1, r2 = lookup.get(side1), lookup.get(side2)
            if r1 is None or r2 is None:
                continue
            a1, a2 = american_number(r1.american_odds), american_number(r2.american_odds)
            q1, q2 = implied_probability(r1.american_odds), implied_probability(r2.american_odds)
            reason = ""
            if None in (a1, a2, q1, q2):
                reason = "unparseable_moneyline"
            elif abs(float(a1)) > 10000 or abs(float(a2)) > 10000:
                reason = "extreme_moneyline"
            elif not 0.90 <= float(q1) + float(q2) <= 1.35:
                reason = "implausible_two_way_overround"
            if reason:
                rejected.append({"Year": int(str(fight.ufc_event_date_iso)[:4]), "FightID": fight.ufc_fight_id, "Book": book, "Odds1": a1, "Odds2": a2, "Reason": reason, "SourceURL": fight.event_url})
                continue
            overround = float(q1) + float(q2)
            p1, p2 = float(q1) / overround, float(q2) / overround
            winner = norm_name(fight.winner_name)
            if winner == side1:
                outcome1 = 1
            elif winner == side2:
                outcome1 = 0
            else:
                continue
            predicted1 = int(p1 >= p2)
            correct = int(predicted1 == outcome1)
            outcome_probability = p1 if outcome1 else p2
            records.append({
                "Year": int(str(fight.ufc_event_date_iso)[:4]), "Event": fight.ufc_event_name,
                "Date": fight.ufc_event_date_iso, "FightID": fight.ufc_fight_id,
                "Fighter1": fight.fighter_1_name, "Fighter2": fight.fighter_2_name,
                "Winner": fight.winner_name, "FightOrder": int(fight.fight_order),
                "WeightClass": fight.weight_class, "Book": book,
                "AmericanOdds1": float(a1), "AmericanOdds2": float(a2),
                "RawImplied1": float(q1), "RawImplied2": float(q2), "Overround": overround,
                "NoVigP1": p1, "NoVigP2": p2, "Confidence": max(p1, p2),
                "PredictedWinner": fight.fighter_1_name if predicted1 else fight.fighter_2_name,
                "Correct": correct, "OutcomeProbability": outcome_probability,
                "LogLossContribution": -math.log(max(min(outcome_probability, 1 - 1e-12), 1e-12)),
                "SourceURL": fight.event_url,
            })
    df = pd.DataFrame(records)
    if df.empty:
        raise RuntimeError("No paired book forecasts built")
    # Remove only catastrophic likely column-alignment errors, not ordinary disagreement.
    df["CrossBookMedianP1"] = df.groupby("FightID").NoVigP1.transform("median")
    counts = df.groupby("FightID").NoVigP1.transform("count").to_numpy()
    p = np.clip(df.NoVigP1.to_numpy(float), 1e-6, 1 - 1e-6)
    m = np.clip(df.CrossBookMedianP1.to_numpy(float), 1e-6, 1 - 1e-6)
    logit_gap = np.abs(np.log(p / (1 - p)) - np.log(m / (1 - m)))
    direction_conflict = ((p >= .5) != (m >= .5)) & (np.abs(p - m) > .45)
    bad = (counts >= 3) & (direction_conflict | (logit_gap > 3.5))
    for _, row in df.loc[bad].iterrows():
        rejected.append({"Year": row.Year, "FightID": row.FightID, "Book": row.Book, "Odds1": row.AmericanOdds1, "Odds2": row.AmericanOdds2, "Reason": "catastrophic_cross_book_alignment_outlier", "SourceURL": row.SourceURL})
    df = df.loc[~bad].copy()
    valid_books = df.groupby("FightID").Book.transform("nunique")
    is_ppv = df.Event.str.match(r"^UFC\s+\d+\b", case=False, na=False)
    is_title = df.WeightClass.astype(str).str.contains("Title Bout", case=False, na=False)
    df["ValidBooks"] = valid_books
    df["LiquidityRaw"] = (
        np.sqrt(valid_books.astype(float)) * np.where(is_ppv, 1.20, 1.0) *
        np.where(df.FightOrder.eq(1), 1.35, np.where(df.FightOrder.eq(2), 1.15, 1.0)) *
        np.where(is_title, 1.15, 1.0)
    )
    weights = df[["Year", "FightID", "LiquidityRaw"]].drop_duplicates()
    weights["LiquidityProxyWeight"] = weights.LiquidityRaw / weights.groupby("Year").LiquidityRaw.transform("mean")
    df = df.merge(weights[["FightID", "LiquidityProxyWeight"]], on="FightID", how="left")
    fights = df.groupby("FightID", as_index=False).agg(
        Year=("Year", "first"), Event=("Event", "first"), Date=("Date", "first"),
        Fighter1=("Fighter1", "first"), Fighter2=("Fighter2", "first"), Winner=("Winner", "first"),
        FightOrder=("FightOrder", "first"), WeightClass=("WeightClass", "first"),
        ValidBooks=("Book", "nunique"), LiquidityProxyWeight=("LiquidityProxyWeight", "first"),
        SourceURL=("SourceURL", "first"),
    ).sort_values(["Year", "Date", "Event", "FightOrder"])
    return df.sort_values(["Year", "Date", "FightID", "Book"]), fights, pd.DataFrame(rejected)


def wmean(values: np.ndarray, weights: np.ndarray) -> float:
    return float(np.sum(values * weights) / np.sum(weights))


def fixed_ece(conf: np.ndarray, correct: np.ndarray, weights: np.ndarray, n_bins: int = 20) -> float:
    ids = np.clip(np.digitize(conf, np.linspace(.5, 1, n_bins + 1)[1:-1]), 0, n_bins - 1)
    total, result = float(weights.sum()), 0.0
    for b in range(n_bins):
        mask = ids == b
        if mask.any():
            bw = float(weights[mask].sum())
            result += bw / total * abs(wmean(conf[mask], weights[mask]) - wmean(correct[mask], weights[mask]))
    return result


def percentile_ece(conf: np.ndarray, correct: np.ndarray, weights: np.ndarray, n_bins: int = 20) -> float:
    order = np.argsort(conf, kind="mergesort")
    sorted_w = weights[order]
    midpoint = np.cumsum(sorted_w) - .5 * sorted_w
    sorted_ids = np.minimum((midpoint / sorted_w.sum() * n_bins).astype(int), n_bins - 1)
    ids = np.empty_like(sorted_ids)
    ids[order] = sorted_ids
    total, result = float(weights.sum()), 0.0
    for b in range(n_bins):
        mask = ids == b
        if mask.any():
            bw = float(weights[mask].sum())
            result += bw / total * abs(wmean(conf[mask], weights[mask]) - wmean(correct[mask], weights[mask]))
    return result


def calculate_metrics(df: pd.DataFrame) -> pd.DataFrame:
    available = df.groupby("Year").FightID.nunique().to_dict()
    rows = []
    for year in sorted(df.Year.unique()):
        year_df = df[df.Year == year]
        max_n = int(year_df.groupby("Book").FightID.nunique().max())
        for weighting, weight_col in (("Equal", None), ("Liquidity proxy", "LiquidityProxyWeight")):
            for book, group in year_df.groupby("Book"):
                group = group.drop_duplicates("FightID")
                weights = np.ones(len(group)) if weight_col is None else group[weight_col].to_numpy(float)
                conf, correct = group.Confidence.to_numpy(float), group.Correct.to_numpy(float)
                d5, d10 = conf >= .55, conf >= .60
                n, n5, n10 = len(group), int(d5.sum()), int(d10.sum())
                full = year in (2024, 2025)
                eligible = n >= (40 if full else 20) and n >= .5 * max_n and n5 >= (25 if full else 12) and n10 >= (15 if full else 8)
                logloss = wmean(group.LogLossContribution.to_numpy(float), weights)
                rows.append({
                    "Year": int(year), "Period": str(year) if year < 2026 else "2026 YTD through 2026-08-30",
                    "Weighting": weighting, "Book": book, "N": n,
                    "AvailableFights": int(available[year]), "CoverageRate": n / available[year],
                    "N_d5": n5, "N_d10": n10,
                    "Accuracy_d5": wmean(correct[d5], weights[d5]) if n5 else np.nan,
                    "Accuracy_d10": wmean(correct[d10], weights[d10]) if n10 else np.nan,
                    "LogLoss": logloss, "AverageLogLikelihood": -logloss,
                    "ECE_fixed20": fixed_ece(conf, correct, weights),
                    "ECE_percentile20": percentile_ece(conf, correct, weights),
                    "MeanConfidence": wmean(conf, weights), "ObservedAccuracy": wmean(correct, weights),
                    "Eligible": bool(eligible),
                })
    result = pd.DataFrame(rows)
    for (_, _), indices in result.groupby(["Year", "Weighting"]).groups.items():
        sub = result.loc[indices]
        specs = [("Accuracy_d5", False), ("Accuracy_d10", False), ("LogLoss", True), ("ECE_fixed20", True), ("ECE_percentile20", True)]
        rank_cols = []
        for col, ascending in specs:
            rank_col = "Rank_" + col
            result.loc[indices, rank_col] = sub[col].rank(ascending=ascending, method="min")
            rank_cols.append(rank_col)
        result.loc[indices, "MeanMetricRank"] = result.loc[indices, rank_cols].mean(axis=1)
        eligible_indices = result.loc[indices][result.loc[indices].Eligible].index
        result.loc[eligible_indices, "EligibleLogLossRank"] = result.loc[eligible_indices, "LogLoss"].rank(ascending=True, method="min")
        result.loc[eligible_indices, "EligibleCompositeRank"] = result.loc[eligible_indices, "MeanMetricRank"].rank(ascending=True, method="min")
    return result.sort_values(["Year", "Weighting", "Eligible", "LogLoss"], ascending=[True, True, False, True])


def make_top3(metrics: pd.DataFrame) -> pd.DataFrame:
    eligible = metrics[metrics.Eligible].copy()
    if eligible.empty:
        eligible = metrics.copy()
    top = eligible.sort_values(["Year", "Weighting", "LogLoss", "N"], ascending=[True, True, True, False]).groupby(["Year", "Weighting"], group_keys=False).head(3).copy()
    top["Rank"] = top.groupby(["Year", "Weighting"]).cumcount() + 1
    return top[["Year", "Period", "Weighting", "Rank", "Book", "N", "CoverageRate", "N_d5", "N_d10", "Accuracy_d5", "Accuracy_d10", "LogLoss", "AverageLogLikelihood", "ECE_fixed20", "ECE_percentile20", "MeanMetricRank"]]


def make_leaders(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    specs = [("Accuracy d=5", "Accuracy_d5", False), ("Accuracy d=10", "Accuracy_d10", False), ("Log loss", "LogLoss", True), ("ECE fixed 20", "ECE_fixed20", True), ("ECE percentile 20", "ECE_percentile20", True)]
    for (year, weighting), group in metrics[metrics.Eligible].groupby(["Year", "Weighting"]):
        for label, col, ascending in specs:
            for rank, (_, row) in enumerate(group.sort_values([col, "N"], ascending=[ascending, False]).head(3).iterrows(), 1):
                rows.append({"Year": year, "Weighting": weighting, "Metric": label, "Rank": rank, "Book": row.Book, "Value": row[col], "N": row.N})
    return pd.DataFrame(rows)


def write_report(path: Path, top3: pd.DataFrame, metrics: pd.DataFrame, fights: pd.DataFrame, forecasts: pd.DataFrame, failures: pd.DataFrame, unmatched: pd.DataFrame, rejects: pd.DataFrame) -> None:
    def pct(x: Any) -> str:
        return "—" if pd.isna(x) else f"{100 * float(x):.2f}%"
    sections = []
    for (year, weighting), group in top3.groupby(["Year", "Weighting"]):
        rows = "".join(f"<tr><td>{int(r.Rank)}</td><td>{r.Book}</td><td>{int(r.N)}</td><td>{pct(r.Accuracy_d5)}</td><td>{pct(r.Accuracy_d10)}</td><td>{r.LogLoss:.5f}</td><td>{r.ECE_fixed20:.5f}</td><td>{r.ECE_percentile20:.5f}</td></tr>" for _, r in group.iterrows())
        sections.append(f"<h3>{year} — {weighting}</h3><table><tr><th>Rank</th><th>Book</th><th>N</th><th>Acc d=5</th><th>Acc d=10</th><th>Log loss</th><th>ECE fixed</th><th>ECE percentile</th></tr>{rows}</table>")
    coverage = fights.groupby("Year").agg(Fights=("FightID", "nunique"), Events=("Event", "nunique"), First=("Date", "min"), Last=("Date", "max"))
    coverage_rows = "".join(f"<tr><td>{y}</td><td>{int(r.Fights)}</td><td>{int(r.Events)}</td><td>{r.First}</td><td>{r.Last}</td></tr>" for y, r in coverage.iterrows())
    html = f"""<!doctype html><meta charset='utf-8'><title>UFC sportsbook sharpness</title><style>body{{font:15px Arial;max-width:1200px;margin:30px auto;color:#172033;line-height:1.45}}table{{border-collapse:collapse;width:100%;margin:10px 0 28px}}th,td{{border:1px solid #ccd5df;padding:7px;text-align:right}}th:nth-child(2),td:nth-child(2){{text-align:left}}th{{background:#102a43;color:white}}.note{{background:#eef4f8;padding:14px;border-left:5px solid #2c7a7b}}</style><h1>UFC sportsbook sharpness, 2024–2026 YTD</h1><div class='note'><b>Primary ranking:</b> lowest no-vig log loss among coverage-eligible books. Volume weighting is an estimated liquidity proxy, not reported handle.</div><h2>Coverage</h2><table><tr><th>Year</th><th>Fights</th><th>Events</th><th>First</th><th>Last</th></tr>{coverage_rows}</table><h2>Top three by log loss</h2>{''.join(sections)}<h2>Method</h2><p>American closing prices were converted to implied probabilities and normalized so both sides sum to one. Accuracy d=5 scores favorites at 55%+ confidence; d=10 at 60%+. Log loss scores every forecast. ECE uses 20 fixed-width bins and 20 equal-observation/equal-liquidity-mass bins over favorite confidence.</p><p>Liquidity proxy = sqrt(valid quoted books) × numbered-PPV factor × main/co-main factor × title factor, normalized to mean one within year.</p><h2>Audit</h2><p>{len(forecasts):,} valid book-fight forecasts; {len(rejects):,} rejected pairs; {len(unmatched):,} unmatched BFO matchups; {len(failures):,} BFO page failures.</p>"""
    path.write_text(html, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("research_results/ufc_book_sharpness"))
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml"})

    print("Collecting UFCStats outcomes", flush=True)
    ufc_events, ufc_fights = scrape_ufcstats(session)
    print(f"UFC decisive fights: {len(ufc_fights)}", flush=True)
    print("Collecting BestFightOdds event pages", flush=True)
    bfo_events, bfo_matchups, bfo_quotes, failures = scrape_bfo(session)
    print(f"BFO matchups={len(bfo_matchups)}, quote rows={len(bfo_quotes)}", flush=True)
    matched, unmatched = match_fights(bfo_matchups, ufc_fights)
    print(f"Matched fights={len(matched)}", flush=True)
    forecasts, fight_summary, rejects = build_forecasts(matched, bfo_quotes)
    metrics = calculate_metrics(forecasts)
    top3, leaders = make_top3(metrics), make_leaders(metrics)

    ufc_events.to_csv(out / "ufcstats_events.csv", index=False)
    ufc_fights.to_csv(out / "ufcstats_decisive_fights.csv", index=False)
    bfo_events.to_csv(out / "bestfightodds_events.csv", index=False)
    bfo_matchups.to_csv(out / "bestfightodds_matchups.csv", index=False)
    bfo_quotes.to_csv(out / "bestfightodds_quote_rows.csv", index=False)
    failures.to_csv(out / "bestfightodds_page_failures.csv", index=False)
    matched.to_csv(out / "matched_fights.csv", index=False)
    unmatched.to_csv(out / "unmatched_matchups.csv", index=False)
    rejects.to_csv(out / "qc_exclusions.csv", index=False)
    forecasts.to_csv(out / "fight_level_forecasts.csv", index=False)
    fight_summary.to_csv(out / "fight_summary.csv", index=False)
    metrics.to_csv(out / "sportsbook_scorecard.csv", index=False)
    top3.to_csv(out / "top3_by_year_weighting.csv", index=False)
    leaders.to_csv(out / "metric_leaders.csv", index=False)

    payload = {
        "scope": {"start": START_DATE.isoformat(), "end": END_DATE.isoformat()},
        "counts": {"ufcstats_decisive_fights": len(ufc_fights), "bfo_matchups": len(bfo_matchups), "matched_fights": int(fight_summary.FightID.nunique()), "valid_book_fight_forecasts": len(forecasts), "books": sorted(forecasts.Book.unique().tolist()), "page_failures": len(failures), "unmatched_matchups": len(unmatched), "qc_exclusions": len(rejects)},
        "top3": top3.replace({np.nan: None}).to_dict(orient="records"),
        "scorecard": metrics.replace({np.nan: None}).to_dict(orient="records"),
    }
    (out / "results.json").write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    write_report(out / "report.html", top3, metrics, fight_summary, forecasts, failures, unmatched, rejects)
    (out / "README.md").write_text(
        "# UFC sportsbook sharpness results\n\n"
        f"Scope: {START_DATE} through {END_DATE}. Matched fights: {fight_summary.FightID.nunique():,}. Valid book-fight forecasts: {len(forecasts):,}.\n\n"
        "Primary ranking is lowest no-vig log loss among coverage-eligible books. Volume weighting is a liquidity proxy based on quote depth and card/bout prominence, normalized within year; it is not actual handle. BestFightOdds completed-event display prices are closing-line proxies, not perfectly synchronized timestamp-certified closes.\n",
        encoding="utf-8",
    )
    print("\nTOP 3 BY LOG LOSS\n" + top3.to_string(index=False), flush=True)
    print(f"Wrote {out.resolve()}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
